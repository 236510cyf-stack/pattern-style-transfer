---
name: pattern-style-transfer
description: Analyze a reference pattern or plate decoration and create an original, text-free design in the same visual system, delivered as a flat circular print artwork plus its matching complete flat master. Use for ornamental patterns, surface decoration, and circular dinnerware print designs; not for typography, logos, posters, or general photographic style transfer.
---

# Pattern Style Transfer

Create an original pattern from the reusable visual system of the user's reference image. Transfer relationships, proportions, rhythm, density, shape language, color roles, and surface treatment; do not trace the reference's exact motifs or copy text, logos, signatures, or watermarks.

## Determine the task

After receiving the reference image(s), offer a concise scheme-count choice when the interface supports selectable options: `生成 1 套`、`生成 2 套`、`生成 3 套`、`自定义数量`. If the user does not choose a count, generate **one scheme** by default. An explicit count in the user's request or an automation takes precedence; do not pause an unattended run to ask. If the user asks for separate schemes from separate references, give each scheme its own reference, complete flat master, and matching circular print artwork.

Classify the reference as a flat pattern, repeat pattern, circular plate design, or photograph of a decorated plate. Classify the request as:

- **Theme replacement:** replace the reference motifs with the user's new subject.
- **Same-theme variation:** keep the subject category but redesign poses, details, and combinations. Use this by default when no new theme is given.
- **Circular print adaptation:** fit the flat master into a circular print area, allowing only the circular boundary to crop peripheral motifs.

Follow explicit user choices first, then circular print geometry, then the reference's composition and styling. When several references are provided, use the user's stated roles; otherwise choose one primary composition and use the others only for clearly compatible color, shape, or texture cues.

For the full extraction framework, read [references/style-analysis.md](references/style-analysis.md).

## Isolate decoration from photography

For a photographed plate, infer the true circular surface and analyze only the applied decoration. Ignore camera perspective, table, props, shadows, glare, reflections, stains, and background. The output remains flat artwork even when the reference is a plate photo.

## Color and opacity treatment

- Render the transferred decorative motifs at approximately **115% of the reference's effective saturation**, increasing saturation by 15% while preserving hue relationships, value hierarchy, contrast roles, and legibility.
- Increase the decorative motifs' transparency by approximately **6% relative to the reference's transferred treatment** (equivalently, reduce motif opacity by approximately 6%, bounded between fully transparent and fully opaque). Apply this to motifs and linework, never to the solid white flat-master background.
- Apply these reference-relative adjustments **once** when creating the complete flat master. The pattern inside the circular print artwork must be copied from that master without any additional change to motif content, hue, brightness, saturation, transparency, opacity, linework, or color relationships. Prefer a direct circular mask/crop of the master over generating a new interpretation. If any rendering step changes the pattern, correct it against the master before delivery.

## Floral detail rule

For floral motifs, make the color transition into and within each flower center natural and continuous. Render stamens and flower centers as clear, flat artwork with clean edges and readable structure. Avoid muddy gradients, speckles, gritty texture, and accidental pseudo-text in the flower center. Preserve these details unchanged in the circular print artwork.

## Mandatory creation sequence

Use the available image-generation capability. Always build one complete, uncropped, text-free flat artwork first as the master composition. Then derive the circular print artwork from that same master by placing the design inside a circle and cropping only at the circular boundary.

Do not design the two deliverables independently. Do not generate the circular version first and invent the missing edge content afterward.

1. Extract the reference's composition topology, motif hierarchy, rhythm, density, negative space, shape language, color roles, and material treatment.
2. Separate reusable style rules from reference-specific content.
3. Create one complete flat master artwork with every motif fully drawn.
4. Derive the flat circular print artwork from the master, using the circular boundary to crop peripheral motifs when needed. Keep the artwork upright and unchanged within the circle; leave the area outside the circle transparent by default.
5. Deliver the two images in the order specified below, even though the master was created first internally.

## Mandatory two-image delivery

Return two separate images, never a collage, split screen, contact sheet, or two panels inside one image.

### Image 1 — Flat circular print artwork

- Show a clean, centered circle containing the flat master pattern. Use a circular mask to crop the artwork; do not present a dinner plate or product mockup.
- Preserve the master artwork's motif positions, scale relationships, directions, overlaps, colors, linework, and rhythm.
- Keep the pattern's brightness, saturation, transparency, and opacity identical to the flat master; do not recolor, re-render, relight, or reinterpret it.
- Let the circular boundary naturally crop peripheral flowers, leaves, animals, or other motifs. Cropping must come from the circle, not from incompletely drawn master motifs.
- Keep the circle interior's background pure white and the exterior transparent by default. No plate rim, curve, glaze, perspective, highlight, shadow, tabletop, or photographic background.

### Image 2 — Complete flat pattern

- Return the original complete master artwork used for Image 1.
- Use a clean solid white background. Do not use transparency, off-white, cream, tinted paper, gradients, or photographic backgrounds.
- Show no plate, rim, curvature, perspective, glaze, highlight, shadow, tabletop, prop, or product-photography background.
- Reveal the complete forms of all motifs cropped by the circular boundary in Image 1.
- Preserve the same motif anchors, count, relative positions, scale, direction, overlap, color, linework, texture, and visual rhythm.
- Expand the canvas when necessary to reveal complete edge motifs; do not shrink or rearrange the whole composition merely to avoid cropping.
- Do not add, remove, replace, or independently redesign motifs when producing this image.
- Keep the white background uniform through the full canvas, including behind peripheral motifs.

Neither image may contain words, letters, numbers, logos, signatures, watermarks, seals, or pseudo-text glyphs.

## Optional 4K enlargement after delivery

After delivering the normal pair, offer the action `放大4K（完整图案）` for the complete flat artwork. Run it only when the user selects or requests it; do not enlarge the circular print artwork unless separately requested. Use `$image-hd-refiner` on the saved flat master, targeting a long edge of at least 3840 pixels while preserving aspect ratio and the full composition. Keep hue, brightness, saturation, opacity, white background, shapes, and placement unchanged. Remove fine noise, dirty grain, speckles, and compression artifacts; make lines clear and continuous, surfaces smooth, and colors harmonious without recoloring. Save the 4K result as a separate PNG beside the original, with a `4K` filename suffix, and never overwrite the original. Follow the refiner's quality gates, including a dimension check and visual comparison. This optional action does not block normal delivery or source-image archiving.

Skill metadata supports one default prompt but no native custom action buttons. Present the scheme-count choices and 4K action as selectable UI options where the host provides them; otherwise give the user the exact action labels or a short prompt they can send. Never claim a clickable button was installed when the host does not provide one.

## Local folder delivery

When the task uses a local folder workflow:

- Save every generated image directly in the root `输出` folder. Do not create date, batch, scheme, or per-reference subfolders inside `输出`.
- Include the run date and time plus the scheme and deliverable role in every filename, for example `2026-11-11_142124_方案A_01-圆形印刷稿.png` and `2026-11-11_142124_方案A_02-完整平面图.png`.
- Move every successfully processed source image directly into the root `已处理图片` folder. Do not create date, batch, or scheme subfolders inside `已处理图片`.
- Never overwrite an existing file. Add a unique suffix when a filename already exists.
- Move source images only after every required deliverable for the run has been saved and validated successfully.

## Scope

These are visual presentation images only. Do not request or validate physical dimensions, bleed, safe areas, DPI, CMYK values, spot colors, printing processes, ceramic firing processes, or production file formats unless the user explicitly asks for them.

## Validate before delivery

Read [references/quality-check.md](references/quality-check.md) and compare both images. If composition consistency, complete edge motifs, originality, or absence of text fails, correct the result before delivery.
