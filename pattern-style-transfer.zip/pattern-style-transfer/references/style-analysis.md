# Style Analysis Framework

Extract a reusable design system rather than a list of objects or sampled colors.

## Composition topology

- Identify the focal point, symmetry, radial or circular organization, visual flow, overlap, and foreground/background structure.
- For plates, distinguish center field, transition ring, border band, outer rim, and deliberate empty space.
- Record relative proportions and anchor relationships rather than absolute coordinates.

## Motif system

- Separate primary, supporting, and filler motifs.
- Identify how forms are simplified, exaggerated, geometricized, stylized, connected, intertwined, or overlapped.
- Preserve the method of depiction while replacing reference-specific poses and distinctive combinations with original ones.

## Repetition and rhythm

- Identify translation, rotation, mirroring, alternation, radial repetition, spacing, size sequences, and controlled variation.
- For circular work, inspect whether motifs follow the circumference and remain balanced under rotation.
- For repeat patterns, preserve edge continuity only when the user requests a seamless repeat.

## Density and negative space

- Identify dense zones, quiet zones, exposed-background ratio, filler frequency, and the density contrast between the center and border.
- Preserve density structure instead of merely matching the number of objects.

## Line and shape language

- Inspect outline weight, regularity, curvature, sharpness, softness, hand-drawn irregularity, interior marks, hatching, dots, and color-block construction.
- Describe whether forms are rounded, elongated, angular, flattened, graphic, naturalistic, or symbolic.

## Color roles

- Identify background, primary, supporting, outline, and accent colors.
- Preserve area ratios, value contrast, saturation contrast, temperature relationships, and adjacent-color behavior rather than exact sampled values alone.

## Surface treatment

- Identify flat paint, hand painting, block print, screen print, engraving, embroidery, underglaze, overglaze, grain, wear, registration shift, or uneven pigment.
- Do not mistake photographic glare, lens noise, shadows, stains, or reflections for artwork texture.

## Transfer plan

Build an internal plan with:

- **Preserve:** composition, proportions, rhythm, density, shape logic, color roles, and surface behavior essential to recognition.
- **Adapt:** motifs and secondary color choices required by the user's subject.
- **Replace:** literal reference content and distinctive arrangements that should not be traced.
- **Exclude:** all typography, branding, signatures, watermarks, pseudo-text, and photographic artifacts.
