# Two-Image Quality Check

Score each item internally as 0 (failed), 1 (partial), or 2 (good):

- The result transfers composition and rhythm, not just color.
- Primary, supporting, and filler motif proportions are coherent.
- Density and negative-space structure reflect the reference system.
- Line, shape, color-role, and texture treatment are consistent.
- Effective decorative saturation is approximately 15% higher than the reference while hue, value, and contrast relationships remain coherent.
- Decorative motif transparency is approximately 6% higher than the reference's transferred treatment, without making the motifs illegible; the complete flat master's white background remains fully opaque.
- Reference-relative saturation and transparency adjustments are applied once to the flat master; the circular print receives no additional adjustment.
- The new design is an original combination rather than a trace.
- Image 1 is flat circular print artwork that uses only a circular boundary to crop peripheral motifs naturally, with a pure-white interior and transparent exterior by default. It has no dinner plate, rim, glaze, shadow, perspective, or product mockup.
- Image 2 shows the same complete master composition without a circular crop or mockup effects.
- Image 2 uses a uniform clean white background with no transparency, tint, gradient, paper texture, or photographic effects.
- Every motif cropped by the circle in Image 1 is complete in Image 2.
- Motif count, anchors, relative scale, direction, overlap, and colors match across both images.
- The pattern inside the circular print matches the flat master in brightness, saturation, transparency, opacity, hue, and linework, with no re-rendering or color drift.
- Floral centers have natural color transitions and clean, flat, clearly legible stamens without grit or pseudo-text.
- Neither image contains text, pseudo-text, logos, signatures, seals, or watermarks.
- The two deliverables are separate images rather than a collage.

Composition consistency, originality, complete edge motifs, the flat artwork's clean white background, the required reference-relative adjustments, exact pattern color/transparency consistency across the pair, flat circular presentation, floral-center clarity when applicable, and absence of text are critical. If any critical item scores 0, revise before delivery. Use the complete master artwork as the source of truth; never reconcile the pair by independently redesigning both images.
